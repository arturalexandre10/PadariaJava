/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package teste;


public class RepositorioTeste {
    
    
    
    private int indice;
    private Funcionario[] Funcionario;
    private Object numCpf;
    

public void inserir(Funcionario funcionario){
	 Funcionario[indice] = funcionario;
	 indice = indice + 1;
}

public Funcionario procurar (double CpfFuncionario){
	Funcionario procurar = null;
	
	for(int i=0; i<indice; i++){
		Funcionario aux = this.Funcionario[i];
		
		if(aux.getCpf().equals(numCpf))
			procurar = aux;
	}
	return procurar;
}
}
