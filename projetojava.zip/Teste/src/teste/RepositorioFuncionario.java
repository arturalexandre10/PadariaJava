    package teste;


public class RepositorioFuncionario {
    
    
    
    private int indice;
    private Funcionario[] Funcionario;
    private Object numCpf;
    

public void inserir(Funcionario funcionario){
	 Funcionario[indice] = funcionario;
	 indice = indice + 1;
}

public Funcionario procurar (double CpfFuncionario){
	Funcionario procurar = null;
	
	for(int i=0; i<indice; i++){
		Funcionario aux = this.Funcionario[i];
		
		if(aux.getCpf().equals(numCpf))
			procurar = aux;
	}
	return procurar;
}
}
